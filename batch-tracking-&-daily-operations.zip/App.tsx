
import React, { useState } from 'react';
import { AppProvider, useApp } from './store';
import { UserRole } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import DrPhoneQC from './pages/DrPhoneQC';
import Reports from './pages/Reports';
import AdminPanel from './pages/AdminPanel';
import Login from './pages/Login';
import DataGuide from './pages/DataGuide';

const MainLayout: React.FC = () => {
  const { user, logout } = useApp();
  const [activeTab, setActiveTab] = useState('dashboard');

  if (!user) return <Login />;

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'qc': return <DrPhoneQC />;
      case 'reports': return <Reports />;
      case 'guide': return <DataGuide />;
      case 'admin': return <AdminPanel />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} userRole={user.role} logout={logout} />
      <main className="flex-1 overflow-y-auto p-4 md:p-8">
        <div className="max-w-7xl mx-auto">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
};

export default App;
