
export enum UserRole {
  ADMIN = 'ADMIN',
  TECHNICIAN = 'TECHNICIAN',
  VIEWER = 'VIEWER'
}

export interface User {
  id: string;
  username: string;
  role: UserRole;
  email: string;
}

export enum BatchType {
  NEW_PURCHASE = 'New Purchase',
  CUSTOMER_RETURN = 'Customer Return'
}

export enum BatchStatus {
  ARRIVED = 'Arrived',
  IN_QC = 'In QC',
  PROCESSING = 'Processing',
  COMPLETED = 'Completed'
}

export interface Batch {
  id: string;
  type: BatchType;
  model: string;
  source: string;
  invoice: string;
  quantity: number;
  arrivalDate: string;
  qcPass: number;
  defects: number;
  assigned: number;
  completed: number;
  status: BatchStatus;
}

export enum DeviceStatus {
  PENDING = 'Pending',
  AUTO_PASS = 'Auto Pass',
  MANUAL_QC = 'Manual QC Required',
  REPAIRING = 'In Repair',
  READY = 'Ready for Sale',
  DEFECTIVE = 'Defective'
}

export interface Device {
  imei: string;
  model: string;
  faultType?: string;
  batteryHealth: number;
  cycleCount: number;
  failCount: number;
  testerName: string;
  manualQCFlag: boolean;
  score: number;
  status: DeviceStatus;
  assignedTo?: string;
  uploadDate: string;
}

export interface Technician {
  id: string;
  name: string;
  specialty: string;
}
