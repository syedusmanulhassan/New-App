
import React from 'react';
import { 
  LayoutDashboard, 
  ShieldCheck, 
  BarChart3, 
  Database, 
  Settings, 
  LogOut,
  Package
} from 'lucide-react';
import { UserRole } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userRole: UserRole;
  logout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, userRole, logout }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: [UserRole.ADMIN, UserRole.TECHNICIAN, UserRole.VIEWER] },
    { id: 'qc', label: 'Dr Phone QC', icon: ShieldCheck, roles: [UserRole.ADMIN, UserRole.TECHNICIAN] },
    { id: 'reports', label: 'Reports', icon: BarChart3, roles: [UserRole.ADMIN, UserRole.VIEWER] },
    { id: 'guide', label: 'Data Guide', icon: Database, roles: [UserRole.ADMIN, UserRole.TECHNICIAN, UserRole.VIEWER] },
    { id: 'admin', label: 'Admin Panel', icon: Settings, roles: [UserRole.ADMIN] },
  ];

  return (
    <div className="w-64 bg-slate-900 text-slate-300 flex flex-col h-full border-r border-slate-800">
      <div className="p-6 flex items-center gap-3">
        <div className="bg-indigo-600 p-2 rounded-lg">
          <Package className="text-white w-6 h-6" />
        </div>
        <span className="font-bold text-white tracking-tight">RefurbHub v1.0</span>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1">
        {menuItems.filter(item => item.roles.includes(userRole)).map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              activeTab === item.id 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                : 'hover:bg-slate-800 hover:text-white'
            }`}
          >
            <item.icon size={20} />
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-3 mb-4 px-2">
          <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center font-bold text-slate-100 uppercase">
            {userRole.charAt(0)}
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-white truncate w-32">User Session</span>
            <span className="text-xs text-slate-500">{userRole}</span>
          </div>
        </div>
        <button 
          onClick={logout}
          className="w-full flex items-center gap-3 px-4 py-2 text-slate-400 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors"
        >
          <LogOut size={18} />
          <span className="text-sm font-medium">Log out</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
