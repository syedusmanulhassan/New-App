
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Batch, Device, UserRole, BatchType, BatchStatus, DeviceStatus, Technician } from './types';

interface AppContextType {
  user: User | null;
  batches: Batch[];
  devices: Device[];
  technicians: Technician[];
  login: (username: string, role: UserRole) => void;
  logout: () => void;
  addBatch: (batch: Omit<Batch, 'qcPass' | 'defects' | 'assigned' | 'completed'>) => void;
  updateBatch: (batch: Batch) => void;
  addDevices: (newDevices: Device[]) => void;
  assignTechnician: (imei: string, technicianName: string, faultType: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [devices, setDevices] = useState<Device[]>([]);
  const [technicians, setTechnicians] = useState<Technician[]>([
    { id: '1', name: 'Alex Rivera', specialty: 'iPhone Screens' },
    { id: '2', name: 'Sarah Chen', specialty: 'Mainboard' },
    { id: '3', name: 'Mike Ross', specialty: 'Batteries & Charging' },
  ]);

  // Initial Mock Data
  useEffect(() => {
    const initialBatches: Batch[] = [
      {
        id: 'B-1001',
        type: BatchType.NEW_PURCHASE,
        model: 'iPhone 13 Pro',
        source: 'Global Mobile Corp',
        invoice: 'INV-77821',
        quantity: 50,
        arrivalDate: '2024-05-15',
        qcPass: 32,
        defects: 8,
        assigned: 10,
        completed: 5,
        status: BatchStatus.PROCESSING
      },
      {
        id: 'B-1002',
        type: BatchType.CUSTOMER_RETURN,
        model: 'iPhone 15',
        source: 'Returns Hub',
        invoice: 'RET-009',
        quantity: 12,
        arrivalDate: '2024-05-16',
        qcPass: 0,
        defects: 0,
        assigned: 0,
        completed: 0,
        status: BatchStatus.IN_QC
      }
    ];
    setBatches(initialBatches);
  }, []);

  const login = (username: string, role: UserRole) => {
    setUser({ id: 'u1', username, role, email: `${username}@refurb.com` });
  };

  const logout = () => {
    setUser(null);
  };

  const addBatch = (batchData: Omit<Batch, 'qcPass' | 'defects' | 'assigned' | 'completed'>) => {
    const newBatch: Batch = {
      ...batchData,
      qcPass: 0,
      defects: 0,
      assigned: 0,
      completed: 0
    };
    setBatches(prev => [newBatch, ...prev]);
  };

  const updateBatch = (updatedBatch: Batch) => {
    setBatches(prev => prev.map(b => b.id === updatedBatch.id ? updatedBatch : b));
  };

  const addDevices = (newDevices: Device[]) => {
    setDevices(prev => [...newDevices, ...prev]);
  };

  const assignTechnician = (imei: string, technicianName: string, faultType: string) => {
    setDevices(prev => prev.map(d => {
      if (d.imei === imei) {
        return {
          ...d,
          assignedTo: technicianName,
          faultType,
          status: DeviceStatus.REPAIRING
        };
      }
      return d;
    }));
  };

  return (
    <AppContext.Provider value={{
      user, batches, devices, technicians,
      login, logout, addBatch, updateBatch, addDevices, assignTechnician
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
